from django.apps import AppConfig


class SearchojConfig(AppConfig):
    name = 'searchoj'
